﻿//Drag the Scrubber while player clicks/taps and holds on the scrubber, and reset scrubber position afterwards
//Source of Dragging input code: http://answers.unity3d.com/questions/979738/after-drag-a-gameobject-animation-changes.html

using UnityEngine;
 using System.Collections;
 //Component Requirements
 [RequireComponent(typeof(BoxCollider2D))]
 
 public class Drag : MonoBehaviour {
     //Variables
     private Vector2 screenPoint;
     private Vector2 offset;
     //After dragging is over, reset the scrubber position
     void OnMouseUp() 
     {
         transform.position = new Vector2(2.2f, -3.2f);
     }
     //Drag the scrubber with player drag input
     void OnMouseDrag()
     {
         //Source at top
         Vector2 curScreenPoint = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
         Vector2 curPosition = Camera.main.ScreenToWorldPoint(curScreenPoint);
         transform.position = curPosition;
     }
 }