﻿//Destroy bullet and enemy on collision, and spawn a particle on enemy location
using UnityEngine;
using System.Collections;

public class BulletDestroyScript : MonoBehaviour {
    
    public GameObject DeathParticle;
       
	// Use this for initialization
	void Start () {
	}
	// Update is called once per frame
    void Update()
    {
    }
    //Destroy bullet and enemy on collision and spawn a particle
    void OnTriggerEnter2D(Collider2D WhoCollidedWithMe)
    {
        if (WhoCollidedWithMe.tag == "Bullet")
        {
            //Spawn a particle on dead enemy
            GameObject thisParticle = (GameObject)GameObject.Instantiate(DeathParticle);
            thisParticle.transform.position = new Vector3 (transform.position.x, transform.position.y, -5);
                  GetComponent<Rigidbody2D>().AddForce(new Vector2(Random.Range(-10f,10f),Random.Range(20f,40f)) *30);
            //Destroy bullet and enemy
            Destroy(WhoCollidedWithMe.gameObject);
            DestroyObject(gameObject, 2.0f);
        }
    }
}