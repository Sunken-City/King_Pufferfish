﻿using UnityEngine;
using System.Collections;

public class EnemySpawnScript : MonoBehaviour {

    //Public Variables
    public float EnemySpeed = -1.0f;
    public GameObject EnemySpawner;
    public GameObject Enemy1;
    public int rand = 1;
    //Private Variables
    private GameObject Player;
    float timerStart;

    // Use this for initialization
    void Start()
    {
        //Begin Timer for enemy spawn rate tracking
        timerStart = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        //Spawn enemy ever X seconds. Randomly vary spawn position integer-wise across screen size
        if (Time.time >= timerStart + rand)
        {
            rand = Random.Range(1, 2);
            float randXSpawn = Random.Range(-3, 3) + 0.5f;
            GameObject thisEnemy = (GameObject)GameObject.Instantiate(Enemy1);
            thisEnemy.transform.position = GameObject.Find("EnemySpawner").transform.position;
            thisEnemy.transform.position = new Vector3(randXSpawn, thisEnemy.transform.position.y, 0);
            thisEnemy.GetComponent<Rigidbody2D>().velocity = new Vector2(0.0f, EnemySpeed);
            //Reset timer with new time
            timerStart = Time.time;
        }
    }
}
