﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class PlayerMovement : MonoBehaviour
{
    //Define variables
    public float forceUp = 5.0f;
    private int tapCount;
    private int pipeCount;


    void Start()
    {
        //Begin tap and pipe counts at zero
        tapCount = 0;
        pipeCount = 0;
    }

    void Update()
    {
        //Computer "flap" input with spacebar
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0, forceUp), ForceMode2D.Impulse);
            tapCount++;
        }
        //Tablet "flap" input with tap. Use touchcount instead of tapCount for consistent player taps to all register
        //Tapcount is for number of taps (for determining double-taps) whereas touchcount is for number of overall touches
        if (Input.touchCount == 1 && (Input.GetTouch(0).phase == TouchPhase.Began))
        {
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0, forceUp), ForceMode2D.Impulse);
            tapCount++;
        }
        //Update the "tap count" and "pipe count" GUI text
        GameObject.Find("TapCountText").GetComponent<Text>().text = tapCount.ToString();
        GameObject.Find("PipeCountText").GetComponent<Text>().text = pipeCount.ToString();
    }
    //On trigger update "pipe count" player has passed.
    void OnTriggerEnter2D(Collider2D WhoCollidedWithMe)
    {
        if (WhoCollidedWithMe.tag == "PipeCounter")
        {
            pipeCount++;
        }
    }
}
