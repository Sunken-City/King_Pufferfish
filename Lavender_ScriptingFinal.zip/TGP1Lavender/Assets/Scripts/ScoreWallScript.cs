﻿//Update score text when particle hits any outer boundary wall and destroys particle
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

public class ScoreWallScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
    void OnTriggerEnter2D(Collider2D WhoCollidedWithMe)
    {
        //Check for collision with Particle
        if (WhoCollidedWithMe.tag == "ParticleTag")
        {
            //Update Score
            GameObject.Find("ScoreText").GetComponent<Text>().text = (Convert.ToInt32(GameObject.Find("ScoreText").GetComponent<Text>().text) + 10).ToString();
            //Destroy Particle
            Destroy(WhoCollidedWithMe.gameObject);
        }
    }
}
